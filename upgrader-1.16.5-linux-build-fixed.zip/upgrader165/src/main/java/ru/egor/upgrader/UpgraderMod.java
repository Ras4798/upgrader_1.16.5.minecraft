package ru.egor.upgrader;

import net.fabricmc.api.ModInitializer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.Identifier;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class UpgraderMod implements ModInitializer {
    public static final String MOD_ID = "upgrader";
    private static final Random RANDOM = new Random();
    public static final Item UPGRADER = new UpgraderItem(new Item.Settings().group(ItemGroup.MISC).maxCount(1));

    @Override
    public void onInitialize() {
        Registry.register(Registry.ITEM, new Identifier(MOD_ID, "upgrader"), UPGRADER);
    }

    /** Use the upgrader in your main hand while holding the item to risk in your offhand. */
    public static class UpgraderItem extends Item {
        public UpgraderItem(Settings settings) { super(settings); }

        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            ItemStack tool = player.getStackInHand(hand);
            if (world.isClient) return TypedActionResult.success(tool);

            ItemStack input = player.getOffHandStack();
            if (input.isEmpty() || input.getItem() == UPGRADER) {
                player.sendMessage(new LiteralText("§eАпгрейдер: положи предмет в левую руку, а апгрейдер держи в правой."), true);
                return TypedActionResult.fail(tool);
            }

            Item next = chooseUpgrade(input.getItem());
            if (next == null) {
                player.sendMessage(new LiteralText("§cДля этого предмета пока нет улучшения."), true);
                return TypedActionResult.fail(tool);
            }

            double inputValue = valueOf(input.getItem());
            double targetValue = valueOf(next);
            double chance = Math.max(0.05, Math.min(0.90, 0.90 * inputValue / targetValue));
            if (RANDOM.nextDouble() < chance) {
                int count = input.getCount();
                ItemStack result = new ItemStack(next, Math.min(count, next.getMaxCount()));
                player.setStackInHand(Hand.OFF_HAND, result);
                player.sendMessage(new LiteralText("§aУСПЕХ! Предмет улучшен. Шанс: " + Math.round(chance * 100) + "%"), true);
            } else {
                player.setStackInHand(Hand.OFF_HAND, ItemStack.EMPTY);
                player.sendMessage(new LiteralText("§cПРОВАЛ! Предмет потерян. Шанс был " + Math.round(chance * 100) + "%"), true);
            }
            return TypedActionResult.success(tool);
        }
    }

    // A small hand-authored progression for vanilla items. Add more tiers here as desired.
    private static Item chooseUpgrade(Item input) {
        List<Item> tier;
        if (input == Items.COAL || input == Items.CHARCOAL || input == Items.IRON_NUGGET)
            tier = Arrays.asList(Items.IRON_INGOT, Items.GOLD_INGOT);
        else if (input == Items.IRON_INGOT || input == Items.GOLD_INGOT || input == Items.LAPIS_LAZULI || input == Items.REDSTONE)
            tier = Arrays.asList(Items.DIAMOND, Items.EMERALD);
        else if (input == Items.DIAMOND || input == Items.EMERALD || input == Items.QUARTZ)
            tier = Arrays.asList(Items.NETHERITE_INGOT, Items.DIAMOND_BLOCK);
        else if (input == Items.IRON_SWORD || input == Items.GOLDEN_SWORD)
            tier = Arrays.asList(Items.DIAMOND_SWORD, Items.IRON_AXE);
        else if (input == Items.DIAMOND_SWORD || input == Items.IRON_AXE)
            tier = Arrays.asList(Items.NETHERITE_SWORD, Items.DIAMOND_AXE);
        else if (input == Items.IRON_PICKAXE || input == Items.GOLDEN_PICKAXE)
            tier = Arrays.asList(Items.DIAMOND_PICKAXE, Items.IRON_AXE);
        else if (input == Items.DIAMOND_PICKAXE)
            tier = Arrays.asList(Items.NETHERITE_PICKAXE, Items.DIAMOND_AXE);
        else if (input == Items.IRON_HELMET || input == Items.IRON_CHESTPLATE || input == Items.IRON_LEGGINGS || input == Items.IRON_BOOTS)
            tier = Arrays.asList(Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);
        else if (input == Items.DIAMOND_HELMET || input == Items.DIAMOND_CHESTPLATE || input == Items.DIAMOND_LEGGINGS || input == Items.DIAMOND_BOOTS)
            tier = Arrays.asList(Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS);
        else if (input == Items.DIAMOND_BLOCK || input == Items.EMERALD_BLOCK)
            tier = Arrays.asList(Items.NETHERITE_INGOT, Items.NETHERITE_BLOCK);
        else return null;
        return tier.get(RANDOM.nextInt(tier.size()));
    }

    private static double valueOf(Item item) {
        if (item == Items.COAL || item == Items.CHARCOAL || item == Items.IRON_NUGGET) return 1;
        if (item == Items.IRON_INGOT || item == Items.GOLD_INGOT || item == Items.LAPIS_LAZULI || item == Items.REDSTONE) return 3;
        if (item == Items.DIAMOND || item == Items.EMERALD || item == Items.QUARTZ || item == Items.IRON_SWORD || item == Items.GOLDEN_SWORD || item == Items.IRON_PICKAXE || item == Items.GOLDEN_PICKAXE) return 8;
        if (item == Items.DIAMOND_SWORD || item == Items.IRON_AXE || item == Items.DIAMOND_PICKAXE || item == Items.DIAMOND_BLOCK || item == Items.EMERALD_BLOCK) return 20;
        if (item == Items.NETHERITE_INGOT || item == Items.NETHERITE_BLOCK || item == Items.NETHERITE_SWORD || item == Items.NETHERITE_PICKAXE || item == Items.DIAMOND_HELMET || item == Items.DIAMOND_CHESTPLATE || item == Items.DIAMOND_LEGGINGS || item == Items.DIAMOND_BOOTS) return 40;
        return 10;
    }
}
