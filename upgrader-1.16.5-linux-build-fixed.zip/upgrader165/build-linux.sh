#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo 'ERROR: Install JDK 17 to run this legacy Fabric Loom build.' >&2
  exit 1
fi
JAVA_VERSION=$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')
if [[ -z "$JAVA_VERSION" || "$JAVA_VERSION" -lt 16 ]]; then
  echo "ERROR: Build needs JDK 16+ (JDK 17 recommended). Detected: ${JAVA_VERSION:-unknown}" >&2
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo 'ERROR: Gradle is not installed. Use Gradle 7.x (7.3.3 recommended), then rerun ./build-linux.sh.' >&2
  exit 1
fi

echo '=== Java ==='
java -version
echo '=== Gradle ==='
gradle --version

echo '=== Building Upgrader for Minecraft 1.16.5 ==='
gradle --no-daemon clean build

echo '=== Build output ==='
find build/libs -maxdepth 1 -type f -name '*.jar' -print
