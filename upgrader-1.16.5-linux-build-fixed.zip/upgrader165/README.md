# Upgrader 1.16.5 (prototype)

A small Fabric mod prototype inspired by the supplied Upgrader mod. It is not a complete port of the original GUI or all mechanics.

## Build on Linux

- JDK 17 recommended for running this legacy Loom build (JDK 16+ may work).
- Gradle 7.x recommended; 7.3.3 is a reasonable starting point.
- Run `chmod +x build-linux.sh && ./build-linux.sh`.
- Output should appear under `build/libs/`.

The source targets Java 8 bytecode for Minecraft 1.16.5 compatibility. Build-tool runtime Java version is a separate setting.

Install the resulting JAR with Fabric Loader and Fabric API for Minecraft 1.16.5. This project has not been verified in-game; build success alone does not guarantee runtime correctness.
